# Data dictionary: Riverside Rovers v Northgate Athletic (SYN-00007)

All data is synthetic: clubs, players and events are fictional.
Coordinates are metres on a 105 x 68 pitch. Shares (possession, accuracy) are 0-1.

## players.csv
One row per player who played.

| Column | Meaning |
|---|---|
| player_id, name, number, position, team | Who the player is |
| minutes_played | Minutes on the pitch |
| rating | Match rating, 3-10 |
| Goals | Shooting; higher is better |
| Expected goals (xG) | Shooting; higher is better |
| xG on target (xGOT) | Shooting; higher is better |
| Non-penalty xG | Shooting; higher is better |
| Shots | Shooting; higher is better |
| Shots on target | Shooting; higher is better |
| Headed shots | Shooting; higher is better |
| Top speed (km/h) | Physical performance; higher is better |
| Distance covered (km) | Physical performance; higher is better |
| Running (km) | Physical performance; higher is better |
| Sprinting (km) | Physical performance; higher is better |
| Number of sprints | Physical performance; higher is better |
| Assists | Passing; higher is better |
| Expected assists (xA) | Passing; higher is better |
| Successful passes | Passing; higher is better |
| Successful passes % | Passing; higher is better |
| Accurate long balls | Passing; higher is better |
| Accurate long balls % | Passing; higher is better |
| Line-breaking passes | Passing; higher is better |
| Chances created | Passing; higher is better |
| Big chances created | Passing; higher is better |
| Successful dribbles | Possession; higher is better |
| Successful dribbles % | Possession; higher is better |
| Duels won | Possession; higher is better |
| Duels won % | Possession; higher is better |
| Aerial duels won | Possession; higher is better |
| Aerial duels won % | Possession; higher is better |
| Touches | Possession; higher is better |
| Touches in opposition box | Possession; higher is better |
| Dispossessed | Possession; lower is better |
| Fouls won | Possession; higher is better |
| Defensive contributions | Defending; higher is better |
| Tackles | Defending; higher is better |
| Interceptions | Defending; higher is better |
| Blocked shots | Defending; higher is better |
| Fouls committed | Defending; lower is better |
| Recoveries | Defending; higher is better |
| Possession won final 3rd | Defending; higher is better |
| Dribbled past | Defending; lower is better |
| Clearances | Defending; higher is better |
| Clean sheets | Defending; higher is better |
| Goals conceded while on pitch | Defending; lower is better |
| xG against while on pitch | Defending; lower is better |
| Yellow cards | Discipline; lower is better |
| Red cards | Discipline; lower is better |

## teams.csv
One row per team: goals, shots, xG, xGOT, possession, passes, pass accuracy, final-third entries, pressures, tackles, interceptions, turnovers, fouls, cards, corners, saves, aerial duels, recoveries, distance and sprints.

## moments.csv
One row per moment the engine detected. `engine_headline` is the factual headline; `ai_caption`, `fan_take`, `analyst_take` and `why_it_matters` come from the AI agents (empty if the match wasn't AI-explained). `fact_checked` is true when the narration passed the number check and the Fact Checker. `evidence` holds the engine's structured data as JSON.

## timeline.csv
One row per minute: score, phase (balanced, chaos, control_home, control_away), `momentum_home_share` (home team's share of attacking threat over the last 5 minutes) and running team stats.

## events.jsonl
The raw event feed, one JSON object per line, ready for pipelines (Fabric, Databricks, pandas). Field definitions are in matchsim/README.md.
